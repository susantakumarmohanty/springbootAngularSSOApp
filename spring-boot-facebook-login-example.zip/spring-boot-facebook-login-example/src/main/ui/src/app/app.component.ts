import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Demo';
  authenticated = false;
  greeting = {};

  constructor(private http: HttpClient, private router:Router, private service: ServiceService) {
    this.authenticate();
  }

  authenticate() {

    this.http.get('user').subscribe(response => {
        if (response['name']) {
            this.service.datas.authenticated = true;
            this.service.datas.userData = response;
            this.service.datas.testData = "appCompData";
            this.router.navigate(['/home']);
        } else {
          this.service.datas.authenticated = false;
          this.router.navigate(['/login']);
        }
    }, () => { this.service.datas.authenticated = false; });

  }
}
