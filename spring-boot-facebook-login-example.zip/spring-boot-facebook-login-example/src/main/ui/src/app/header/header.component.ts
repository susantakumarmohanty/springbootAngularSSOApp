import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  logoutFlag: boolean = false;

  constructor(private http: HttpClient, private router:Router, private service: ServiceService) { }

  ngOnInit() {
    this.logoutFlag = this.service.datas.authenticated;
  }

  logout() {
    this.http.post('logout', {}).subscribe(() => {
        this.service.datas.authenticated = false;
        this.logoutFlag = this.service.datas.authenticated;
        this.router.navigate(['/login']);
    });
}

}
