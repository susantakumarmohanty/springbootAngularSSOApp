import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  datas = {
    "authenticated": false,
    "userData": {},
    "testData": "serviceData"
  };
  constructor() { }
}
